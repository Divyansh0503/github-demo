package com.onlineEducationPlatform.assignmentAndQuiz.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.onlineEducationPlatform.assignmentAndQuiz.dto.request.AssignmentSubmitRequest;
import com.onlineEducationPlatform.assignmentAndQuiz.dto.response.ApiResponse;
import com.onlineEducationPlatform.assignmentAndQuiz.dto.response.AssignmentSubmitResponse;
import com.onlineEducationPlatform.assignmentAndQuiz.exception.UnauthorizedAccessException;
import com.onlineEducationPlatform.assignmentAndQuiz.service.AssignmentSubmissionService;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/assignment-submissions")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:4200", allowCredentials = "true")
public class AssignmentSubmissionController {

    private final AssignmentSubmissionService submissionService;


    @PutMapping("/{submissionId}/grade")
    public ResponseEntity<AssignmentSubmitResponse> gradeAssignment(
            @PathVariable String submissionId,
            @RequestParam Integer marks) {
        return ResponseEntity.ok(submissionService.gradeAssignment(submissionId, marks));
    }

    @GetMapping("/course/{courseId}")
    public ResponseEntity<List<AssignmentSubmitResponse>> getSubmissionsByCourse(
            @PathVariable String courseId) {
        return ResponseEntity.ok(submissionService.getSubmissionsByCourse(courseId));
    }

    @GetMapping("/student/{studentId}/course/{courseId}")
    public ResponseEntity<List<AssignmentSubmitResponse>> getSubmissionsByStudent(
            @PathVariable String studentId,
            @PathVariable String courseId) {
        return ResponseEntity.ok(submissionService.getSubmissionsByStudent(studentId, courseId));
    }

    @PostMapping
    public ResponseEntity<ApiResponse<AssignmentSubmitResponse>> submitAssignment(
            @Valid @RequestBody AssignmentSubmitRequest request) {
        return ResponseEntity.ok(ApiResponse.<AssignmentSubmitResponse>builder()
                .message("Assignment submitted successfully")
                .statusCode(201)
                .body(submissionService.submitAssignment(request))
                .build());
    }

    @PutMapping("/{submissionId}")
    public ResponseEntity<ApiResponse<AssignmentSubmitResponse>> updateAssignmentSubmission(
            @PathVariable String submissionId,
            @Valid @RequestBody AssignmentSubmitRequest request) {
        return ResponseEntity.ok(ApiResponse.<AssignmentSubmitResponse>builder()
                .message("Assignment submission updated successfully")
                .statusCode(200)
                .body(submissionService.updateAssignmentSubmission(submissionId, request))
                .build());
    }

    @DeleteMapping("/admin/{submissionId}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Void>> deleteSubmission(
            @PathVariable String submissionId) {
        submissionService.deleteSubmission(submissionId);
        return ResponseEntity.ok(ApiResponse.<Void>builder()
                .message("Assignment submission deleted successfully")
                .statusCode(200)
                .body(null)
                .build());
    }

    @GetMapping("/admin/all")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<AssignmentSubmitResponse>>> getAllSubmissions() {
        return ResponseEntity.ok(ApiResponse.<List<AssignmentSubmitResponse>>builder()
                .message("All submissions fetched successfully")
                .statusCode(200)
                .body(submissionService.getAllSubmissions())
                .build());
    }


}