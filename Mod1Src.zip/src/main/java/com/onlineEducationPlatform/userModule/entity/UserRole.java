package com.onlineEducationPlatform.userModule.entity;

public enum UserRole {
    STUDENT,
    INSTRUCTOR,
    ADMIN
}