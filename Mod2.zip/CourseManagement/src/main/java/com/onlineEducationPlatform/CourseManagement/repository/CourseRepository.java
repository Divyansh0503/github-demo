package com.onlineEducationPlatform.CourseManagement.repository;


import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.onlineEducationPlatform.CourseManagement.entity.Course;

@Repository
public interface CourseRepository extends JpaRepository<Course, String> {
    
    // Find courses by instructor
    List<Course> findByInstructorId(String instructorId);
    
    // Find courses by category
    List<Course> findByCategory(String category);
    
    // Check if course exists and belongs to instructor
    boolean existsByIdAndInstructorId(String courseId, String instructorId);
    
    
    
}