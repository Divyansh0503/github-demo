package com.onlineEducationPlatform.CourseManagement.entity;

public enum CourseCategory {
    PRODUCTIVITY,
    BUSINESS,
    TECHNOLOGY,
    FINANCIAL,
    EDUCATION
}
