package com.onlineEducationPlatform.Communication.Module;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CommunicationModuleApplicationTests {

	@Test
	void contextLoads() {
	}

}
