import { Component, OnInit } from '@angular/core';
import { AuthService } from '../shared/auth.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-communication',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './communication.component.html',
  styleUrls: ['./communication.component.css'],
})
export class CommunicationComponent implements OnInit {
  loggedInUser: any = {}; // Store logged-in user details
  user2Id: string = ''; // User2 ID input
  user2Role: string = ''; // User2 Role input
  messages: any[] = []; // Array to store messages
  newMessage: string = ''; // Input for new message
  conversationStarted: boolean = false; // Flag to check if conversation is started
  receivedMessages: any[] = []; // Array to store received messages

  constructor(private authService: AuthService) {}

  ngOnInit(): void {
    // Retrieve logged-in user details from localStorage
    const user = localStorage.getItem('user');
    if (user) {
      this.loggedInUser = JSON.parse(user);
      this.fetchReceivedMessages(); // Fetch received messages on initialization
    }
  }

  fetchReceivedMessages(): void {
    this.authService.getMessagesReceivedByUser(this.loggedInUser.email).subscribe({
      next: (response) => {
        this.receivedMessages = response.slice(0, 10); // Limit to 10 messages
        console.log('Received Messages:', this.receivedMessages);
      },
      error: (err) => {
        console.error('Error fetching received messages:', err);
        alert('Failed to fetch received messages. Please try again later.');
      },
    });
  }

  startConversation(): void {
    if (!this.user2Id || !this.user2Role) {
      alert('Please provide User2 ID and Role.');
      return;
    }

    // Fetch messages between logged-in user and User2
    this.authService.getMessagesBetweenUsers(this.loggedInUser.email, this.user2Id).subscribe({
      next: (response) => {

        this.messages = response.data.sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()); // Sort messages by timestamp
        console.log('Messages:', this.messages);
        this.conversationStarted = true; // Enable conversation view
      },
      error: (err) => {
        console.error('Error fetching messages:', err);
        alert('Failed to fetch messages. Please try again later.');
      },
    });
  }

  sendMessage(): void {
    const messageData = {
      user1_id: this.loggedInUser.email,
      user1_message: this.newMessage,
      user1_role: this.loggedInUser.role,
      user2_id: this.user2Id,
      user2_message: '',
      user2_role: this.user2Role,
    };

    this.authService.createMessage(messageData).subscribe({
      next: (response) => {
        alert('Message sent successfully.');
        this.newMessage = ''; // Clear input
        this.startConversation(); // Refresh messages
      },
      error: (err) => {
        console.error('Error sending message:', err);
        alert('Failed to send message. Please try again later.');
      },
    });
  }

  endConversation(): void {
    this.conversationStarted = false; // Reset the conversation state
    this.messages = []; // Clear the messages array
    this.newMessage = ''; // Clear the new message input
    this.user2Id = ''; // Optionally clear User2 ID
    this.user2Role = ''; // Optionally clear User2 Role
  }
}