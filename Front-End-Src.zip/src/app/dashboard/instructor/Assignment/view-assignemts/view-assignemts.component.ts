import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from '../../../../shared/auth.service';
import { ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { DeleteAssignmentComponent } from "./delete-assignment/delete-assignment.component";
import { EditAssignmentComponent } from './edit-assignment/edit-assignment.component';

@Component({
  selector: 'app-view-assignemts',
  standalone: true,
  imports: [CommonModule, DeleteAssignmentComponent,EditAssignmentComponent],
  templateUrl: './view-assignemts.component.html',
  styleUrls: ['./view-assignemts.component.css'],
})
export class ViewAssignemtsComponent implements OnInit {

  assignments: any[] = []; // Store assignments
  courseId!: string; // Store courseId dynamically
  showDialog = false;
  selectedAssignmentId!:string;
  showEditDialog = false; // Flag to show edit dialog

  constructor(private authService: AuthService, private route: ActivatedRoute,private router: Router) {}

  ngOnInit(): void {
    this.courseId = this.route.snapshot.paramMap.get('courseId')!; // Get courseId from route
    this.fetchAssignments();
  }

  fetchAssignments(): void {
    this.authService.getAssignmentsByCourse(this.courseId).subscribe({
      next: (data) => {
        this.assignments = data; // Store assignments
      },
      error: (err) => {
        console.error('Error fetching assignments:', err);
        alert('Failed to fetch assignments. Please try again later.');
      },
    });
  }

  onDeleteAssignment(assignmentId: string): void {
    this.selectedAssignmentId = assignmentId;
    this.showDialog = true;
  }
  
  handleDeleteResult(result: boolean): void {
    this.showDialog = false; // Hide the dialog box
    if (result) {
      this.fetchAssignments(); // Refresh the assignments list after successful deletion
    }
  }

  onEditAssignment(assignmentId: string,courseId: string): void {
    this.selectedAssignmentId = assignmentId;
    this.showEditDialog = true;
  }

  handleEditResult(success: boolean): void {
    this.showEditDialog = false;
    if (success) {
      this.fetchAssignments(); // Reload assignments after successful edit
    }
  }
}