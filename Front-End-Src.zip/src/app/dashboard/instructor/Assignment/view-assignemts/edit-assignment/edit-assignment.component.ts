import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../../../../shared/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-edit-assignment',
  standalone: true,
  imports: [FormsModule,ReactiveFormsModule,CommonModule],
  templateUrl: './edit-assignment.component.html',
  styleUrls: ['./edit-assignment.component.css']
})
export class EditAssignmentComponent implements OnInit {
  @Input() courseId!: string; // ID of the course to which the assignment belongs
  @Input() assignmentId!: string; // ID of the assignment to edit
  @Output() editResult = new EventEmitter<boolean>(); // Emit result after editing
  editForm!: FormGroup;
  CID!:string
  sequenceNo!:number;

  constructor(private fb: FormBuilder, private authService: AuthService) {}

  ngOnInit(): void {
    this.initializeForm();
    this.loadAssignmentDetails();
  }

  initializeForm(): void {
    this.editForm = this.fb.group({
      title: ['', Validators.required],
      description: ['', Validators.required],
      totalMarks: [0, [Validators.required, Validators.min(1)]],
      dueDate: ['', Validators.required]
    });
  }

  loadAssignmentDetails(): void {
    this.authService.getAssignmentById(this.assignmentId).subscribe({
      next: (response) => {
        const assignment = response.body; // Access the 'body' field from the response
        console.log('Assignment details loaded:', assignment);
        this.CID = assignment.courseId; // Assuming courseId is part of the assignment details
        this.sequenceNo = assignment.sequenceNo; // Assuming sequenceNo is part of the assignment details
        this.editForm.patchValue({
          title: assignment.title,
          description: assignment.description,
          totalMarks: assignment.totalMarks,
          dueDate: assignment.dueDate,
      
        });
         // Assuming sequenceNo is part of the assignment details
      },
      error: (err) => {
        console.error('Error loading assignment details:', err);
        alert('Failed to load assignment details.');
      }
    });
  }

  onSubmit(): void {
    if (this.editForm.valid) {
      const requestBody = {
        courseId: this.CID, // Assuming courseId is available in the component
        title: this.editForm.value.title,
        description: this.editForm.value.description,
        totalMarks: this.editForm.value.totalMarks,
        dueDate: this.formatDateTime(this.editForm.value.dueDate), // Format dueDate to include time
        sequenceNo: this.sequenceNo 
      };
      console.log('Submitting assignment update:', requestBody);
  
      this.authService.updateAssignment(this.assignmentId, requestBody).subscribe({
        next: () => {
          alert('Assignment updated successfully.');
          this.editResult.emit(true); // Emit success result
        },
        error: (err) => {
          console.error('Error updating assignment:', err);
          alert('Failed to update assignment.');
          this.editResult.emit(false); // Emit failure result
        }
      });
    }
  }
  private formatDateTime(date: string): string {
    // Append a default time to the date (e.g., "12:00:00")
    return `${date}T12:00:00`;
  }
}