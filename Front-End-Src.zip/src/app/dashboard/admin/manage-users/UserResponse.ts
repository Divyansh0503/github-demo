export interface UserResponse {
    message: string;
    users: any[];
  }