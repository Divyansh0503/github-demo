import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../shared/auth.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [ReactiveFormsModule,CommonModule],
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  profileForm!: FormGroup;
  passwordForm!: FormGroup;
  user!: any; // Store user details
  isEditing = false; // Flag for editing profile
  isChangingPassword = false; // Flag for changing password

  constructor(private fb: FormBuilder, private authService: AuthService) {}

  ngOnInit(): void {
    this.loadUserProfile();
    this.initializeForms();
  }

  initializeForms(): void {
    this.profileForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      currentPassword: ['', Validators.required] // Current password is required for profile updates
    });

    this.passwordForm = this.fb.group({
      newPassword: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', Validators.required]
    }, { validators: this.passwordMatchValidator });
  }

  passwordMatchValidator(form: FormGroup): { [key: string]: boolean } | null {
    const newPassword = form.get('newPassword')?.value;
    const confirmPassword = form.get('confirmPassword')?.value;
    return newPassword === confirmPassword ? null : { mismatch: true };
  }

  loadUserProfile(): void {
    this.authService.getUserProfile().subscribe({
      next: (response) => {
        this.user = response.user; // Extract user details from response
      },
      error: (err) => {
        console.error('Error fetching user profile:', err);
        alert('Failed to load user profile.');
      }
    });
  }

  onEditProfile(): void {
    this.isEditing = true;
    this.profileForm.patchValue({
      name: this.user.name,
      email: this.user.email
    });
  }

  cancelEdit(): void {
    this.isEditing = false;
  }

  onUpdateProfile(): void {
    if (this.profileForm.valid) {
      const updatedData = {
        name: this.profileForm.value.name,
        email: this.profileForm.value.email,
        password: this.profileForm.value.currentPassword // Current password is required
      };

      this.authService.updateUserProfile(updatedData).subscribe({
        next: (response) => {
          alert(response.message || 'Profile updated successfully.');
          this.isEditing = false;
          this.loadUserProfile(); // Reload profile after update
        },
        error: (err) => {
          console.error('Error updating profile:', err);
          alert('Failed to update profile.');
        }
      });
    }
  }

  onChangePassword(): void {
    this.isChangingPassword = true;
  }

  cancelPasswordChange(): void {
    this.isChangingPassword = false;
  }

  onUpdatePassword(): void {
    if (this.passwordForm.valid) {
      const passwordData = {
        name: this.user.name, // Include name from user details
        email: this.user.email, // Include email from user details
        password: this.profileForm.value.currentPassword, // Current password is required
        newpassword: this.passwordForm.value.newPassword // Include new password
      };

      this.authService.updateUserProfile(passwordData).subscribe({
        next: (response) => {
          alert(response.message || 'Password updated successfully.');
          this.isChangingPassword = false;
          this.passwordForm.reset(); // Reset the password form after successful update
        },
        error: (err) => {
          console.error('Error updating password:', err);
          alert('Failed to update password.');
        }
      });
    }
  }
}