import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { UserResponse } from '../dashboard/admin/manage-users/UserResponse';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private userApiUrl = 'http://localhost:8080/api/userModule/api'; // Base URL for User Module
  private courseApiUrl = 'http://localhost:8081/api/CourseManagement/api/CourseManagement'; // Base URL for Course Management Module
  private assignmentApiUrl='http://localhost:8082/api/AssignmentAndQuizManagment'; 
  private messageApiUrl='http://localhost:8085/api/CommunicationModule'; // Base URL for Message Module

  constructor(private http: HttpClient) {}

  // Login method for User Module
  login(credentials: { email: string; password: string; role: string }): Observable<any> {
    return this.http.post(`${this.userApiUrl}/auth/login`, credentials, { withCredentials: true });
  }

  // Logout method for User Module
  logout(): Observable<any> {
    return this.http.post(`${this.userApiUrl}/auth/logout`, {}, { withCredentials: true });
  }

  // Get user profile method for User Module
  // getUserProfile(): Observable<any> {
  //   const token = localStorage.getItem('token');
  //   return this.http.get(`${this.userApiUrl}/profile`, {
  //     headers: { Authorization: `Bearer ${token}` },
  //     withCredentials: true,
  //   });
  // }

  // Register method for User Module
  register(userData: { name: string; email: string; password: string; role: string }): Observable<any> {
    return this.http.post(`${this.userApiUrl}/auth/register`, userData, { withCredentials: true });
  }

  //get user profile
  getUserProfile(): Observable<any> {
    const token = localStorage.getItem('token');
    return this.http.get(`${this.userApiUrl}/users/profile`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }
  //update the profile
  updateUserProfile(userData: { name: string; email: string; password?: string }): Observable<any> {
    const token = localStorage.getItem('token');
    return this.http.put(`${this.userApiUrl}/users/profile`, userData, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }

  // Create course method for Course Management Module
  createCourse(courseData: { title: string; description: string; category: string }): Observable<any> {
    const token = localStorage.getItem('token');
    return this.http.post(`${this.courseApiUrl}/courses`, courseData, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }
  // Get instructor-specific courses method
  getInstructorCourses(): Observable<any[]> {
    const token = localStorage.getItem('token');
    return this.http.get<any[]>(`${this.courseApiUrl}/courses/instructor`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }

  // Get all courses method
  getAllCourses(): Observable<any[]> {
    const token = localStorage.getItem('token');
    return this.http.get<any[]>(`${this.courseApiUrl}/courses`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }

  // Enroll in a course method
  enrollInCourse(courseId: string): Observable<any> {
    const token = localStorage.getItem('token');
    return this.http.post(`${this.courseApiUrl}/enrollments/${courseId}/enroll`, {},{
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }

  //Get course by Id
  getCourseDetails(courseId: string): Observable<any> {
    const token = localStorage.getItem('token');
    return this.http.get(`${this.courseApiUrl}/courses/${courseId}`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  } 

  // Delete Course by Id
  deleteCourse(courseId: string): Observable<any> {
    const token = localStorage.getItem('token');
    return this.http.delete(`${this.courseApiUrl}/courses/${courseId}`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }

  //update course
  updateCourse(courseId: string, courseData: { title: string; description: string; category: string }): Observable<any> {
    const token = localStorage.getItem('token');
    return this.http.put(`${this.courseApiUrl}/courses/${courseId}`, courseData, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }
  //get Enrollements for Instructor
  getEnrollments(courseId: string): Observable<any[]> {
    const token = localStorage.getItem('token');
    return this.http.get<any[]>(`${this.courseApiUrl}/enrollments/course/${courseId}`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }


  //Create Assignment for Instructor
  createAssignment(assignmentData: {
    courseId: string;
    title: string;
    description: string;
    totalMarks: number;
    dueDate: string;
    sequenceNo: number;
  }): Observable<any> {
    const token = localStorage.getItem('token');
    if (!token) {
      console.error('Token is missing. User might not be logged in.');
      alert('You are not logged in. Please log in and try again.');
      return throwError(() => new Error('Unauthorized'));
    }
    console.log('Authorization Token:', token); // Debugging: Log the token
    return this.http.post(`${this.assignmentApiUrl}/assignments`, assignmentData, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }

  //Get Assignment By course
  getAssignmentsByCourse(courseId: string): Observable<any[]> {
    const token = localStorage.getItem('token');
    return this.http.get<any[]>(`${this.assignmentApiUrl}/assignments/course/${courseId}`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }
  //Delete Assignment by Course
  deleteAssignment(assignmentId: string): Observable<void> {
    const token = localStorage.getItem('token'); // Retrieve token from local storage
    return this.http.delete<void>(`${this.assignmentApiUrl}/assignments/${assignmentId}`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }

  //Edit Assingment
  updateAssignment(assignmentId: string, assignmentData: { title: string; description: string; totalMarks: number; dueDate: string }): Observable<any> {
    const token = localStorage.getItem('token'); // Retrieve token from local storage
    return this.http.put(`${this.assignmentApiUrl}/assignments/${assignmentId}`, assignmentData, {
      headers: { Authorization: `Bearer ${token}` }, // Add Authorization header
      withCredentials: true, // Include credentials for cross-origin requests
    });
  }
  // Get Assignment Details by Id
  getAssignmentById(assignmentId: string): Observable<any> {
    const token = localStorage.getItem('token'); // Retrieve token from local storage
    return this.http.get(`${this.assignmentApiUrl}/assignments/${assignmentId}`, {
      headers: { Authorization: `Bearer ${token}` }, // Add Authorization header
      withCredentials: true, // Include credentials for cross-origin requests
    });
  }

  //Create Quiz
  createQuiz(quizRequest: any): Observable<any> {
    const token = localStorage.getItem('token'); // Retrieve token from local storage
    return this.http.post<any>(`${this.assignmentApiUrl}/quizzes`, quizRequest, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }

  //View  Qizes by CourseId
  getQuizzesByCourse(courseId: string): Observable<any[]> {
    const token = localStorage.getItem('token'); // Retrieve token from local storage
    return this.http.get<any[]>(`${this.assignmentApiUrl}/quizzes/course/${courseId}`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }
  //Delete Quiz by Id
  deleteQuiz(quizId: string): Observable<void> {
    const token = localStorage.getItem('token'); // Retrieve token from local storage
    return this.http.delete<void>(`${this.assignmentApiUrl}/quizzes/${quizId}`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }

  //Get Student's Enrolled Courses
  getStudentEnrollments(): Observable<any[]> {
    const token = localStorage.getItem('token'); // Retrieve token from local storage
    return this.http.get<any[]>(`${this.courseApiUrl}/enrollments/student`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }
  //UnEnroll From Course
  unenrollFromCourse(courseId: string): Observable<void> {
    const token = localStorage.getItem('token'); // Retrieve token from local storage
    return this.http.delete<void>(`${this.courseApiUrl}/enrollments/${courseId}/unenroll`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }
  
  //Submit Assignment
  submitAssignment(request: any): Observable<any> {
    const token = localStorage.getItem('token'); // Retrieve token from local storage
    return this.http.post<any>(`${this.assignmentApiUrl}/assignment-submissions`, request, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }

    // Submit quiz answers
    submitQuiz(request: any): Observable<any> {
      const token = localStorage.getItem('token'); // Retrieve token from local storage
      return this.http.post<any>(`${this.assignmentApiUrl}/quiz-submissions`, request, {
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });
    }

      // Fetch details of a specific quiz
    getQuizDetails(quizId: string): Observable<any> {
      const token = localStorage.getItem('token'); // Retrieve token from local storage
      return this.http.get<any>(`${this.assignmentApiUrl}/quizzes/${quizId}`, {
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });
    }

  // Get progress for a specific course
  getSubmissionsByStudent(studentId: string, courseId: string): Observable<any> {
    const token = localStorage.getItem('token'); // Retrieve token from local storage
    return this.http.get<any>(`${this.assignmentApiUrl}/quiz-submissions/student/${studentId}/course/${courseId}`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }
  
  getSubmissionResult(submissionId: string): Observable<any> {
    const token = localStorage.getItem('token'); // Retrieve token from local storage
    return this.http.get<any>(`${this.assignmentApiUrl}/quiz-submissions/${submissionId}`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }

  // get marks by student and course and quiz
  getMarksByStudentIdAndCourseIdAndQuizId(studentId: string, courseId: string, quizId: string): Observable<number> {
    const token = localStorage.getItem('token'); // Retrieve token from local storage
    return this.http.get<number>(`${this.assignmentApiUrl}/quiz-submissions/student/${studentId}/course/${courseId}/quiz/${quizId}/marks`, {
      headers: { Authorization: `Bearer ${token}` },
      withCredentials: true,
    });
  }
  //get all users
  getAllUsers(): Observable<UserResponse> {
    const token = localStorage.getItem('token'); // Retrieve token from local storage
    return this.http.get<UserResponse>(`${this.userApiUrl}/all/users`, {
      headers: { Authorization: `Bearer ${token}` }, // Add Authorization header
      withCredentials: true, // Include credentials for cross-origin requests
    });
  }

  // Delete user by ID
  deleteUserById(userId: string): Observable<void> {
    const token = localStorage.getItem('token'); // Retrieve token from local storage
    return this.http.delete<void>(`${this.userApiUrl}/users/${userId}`, {
      headers: { Authorization: `Bearer ${token}` }, // Add Authorization header
      withCredentials: true, // Include credentials for cross-origin requests
    });
  }

    // Fetch submissions by course
    getSubmissionsByCourse(courseId: string): Observable<any[]> {
      const token = localStorage.getItem('token'); // Retrieve token from local storage
      console.log('Authorization Header:', { Authorization: `Bearer ${token}` });
      return this.http.get<any[]>(`${this.assignmentApiUrl}/assignment-submissions/course/${courseId}`, {
        headers: { Authorization: `Bearer ${token}` }, // Add Authorization header
        withCredentials: true, // Include credentials for cross-origin requests
      });
      
    }
    
    // Grade an assignment
    gradeAssignment(submissionId: string, marks: number): Observable<any> {
      const token = localStorage.getItem('token'); // Retrieve token from local storage
    
      return this.http.put<any>(
        `${this.assignmentApiUrl}/assignment-submissions/${submissionId}/grade?marks=${marks}`,
        {}, // Empty body as marks are passed in the query parameter
        {
          headers: { Authorization: `Bearer ${token}` }, // Add Authorization header
          withCredentials: true, // Include credentials for cross-origin requests
        }
      );
    }
    // Get messages between two users
    getMessagesBetweenUsers(user1Id: string, user2Id: string): Observable<{ data: any[]; message: string; status: number }> {
      const token = localStorage.getItem('token');
      return this.http.get<{ data: any[]; message: string; status: number }>(
        `${this.messageApiUrl}/messages/between/${user1Id}/${user2Id}`,
        {
          headers: { Authorization: `Bearer ${token}` },
          withCredentials: true,
        }
      );
    }
    // Create a new message between two users
    createMessage(messageData: {
      user1_id: string;
      user1_message: string;
      user1_role: string;
      user2_id: string;
      user2_message: string;
      user2_role: string;
    }): Observable<any> {
      const token = localStorage.getItem('token');
      return this.http.post(`${this.messageApiUrl}/messages`, messageData, {
        headers: { Authorization: `Bearer ${token}` },
        withCredentials: true,
      });
    }

    // Get NEW messages for a user
    getMessagesReceivedByUser(userEmail: string): Observable<any[]> {
      return this.http.get<any[]>(`${this.messageApiUrl}/messages/received/${userEmail}`);
    }
 
}